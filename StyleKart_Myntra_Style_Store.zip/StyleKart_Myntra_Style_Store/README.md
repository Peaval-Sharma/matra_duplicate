# StyleKart — Fashion Shopping Website

A Myntra-inspired **educational shopping website** built using HTML, Tailwind CSS, JavaScript, Node.js, Express.js and EJS. It is an original demo design, not an official Myntra product.

## Features
- Responsive fashion storefront and product cards
- Product categories, search and sorting
- Dynamic product detail URLs (`/product/:id`)
- Add to bag, quantity controls and remove item (browser `localStorage`)
- Demo checkout form and order confirmation
- Orders saved to `data/orders.json` using Node.js `fs`
- MVC folder structure, Express Router, middleware and 404 page
- EJS templates for dynamic UI

## Requirements
Install Node.js (LTS) and VS Code.

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `StyleKart_Myntra_Style_Store` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

```bash
npm install
npm start
```

5. Open `http://localhost:3000`.

For auto-restart while coding:

```bash
npm run dev
```

## Useful URLs
- Home: `http://localhost:3000/`
- All products: `http://localhost:3000/shop`
- Men: `http://localhost:3000/shop?category=Men`
- Search: `http://localhost:3000/shop?q=shoes`
- Sort: `http://localhost:3000/shop?sort=low`
- Product detail: `http://localhost:3000/product/1`
- Checkout: `http://localhost:3000/checkout`
- 404 test: `http://localhost:3000/this-page-does-not-exist`

## Folder structure

```text
StyleKart_Myntra_Style_Store/
├── controllers/
│   └── shopController.js
├── data/
│   └── orders.json
├── models/
│   ├── orderModel.js
│   └── productModel.js
├── public/
│   ├── css/style.css
│   └── js/main.js
├── routes/
│   └── shopRoutes.js
├── views/
│   ├── partials/
│   │   ├── header.ejs
│   │   └── footer.ejs
│   ├── 404.ejs
│   ├── checkout.ejs
│   ├── home.ejs
│   ├── product.ejs
│   ├── shop.ejs
│   └── success.ejs
├── app.js
├── package.json
└── README.md
```

## Node.js syllabus concepts used

| Syllabus topic | Where it is used |
|---|---|
| Node.js intro / first file | `app.js` |
| Core modules / require | `require()` in server and models |
| First server / request-response | Express server and route handlers |
| Event loop / async | `fetch()` checkout request and Node runtime |
| NPM and scripts | `package.json` |
| Nodemon | `npm run dev` |
| Express routes | `routes/shopRoutes.js` |
| Middleware | body parsers, static files, error and 404 handlers in `app.js` |
| Dynamic paths | `/product/:id`, `/order-success/:id` |
| EJS dynamic UI | `views/*.ejs` |
| MVC | `models/`, `views/`, `controllers/` |
| File operations | `models/orderModel.js` reads/writes `data/orders.json` |
| JavaScript in browser | `public/js/main.js`, cart and localStorage |

## Important notes
- This is a learning/demo project. It does not take real payments or send real orders to a delivery company.
- Product photos are loaded from Unsplash, so an internet connection is needed for those images.
- Tailwind CSS is loaded through its CDN for easy setup.
- For a real store, add authentication, database, payment gateway, server-side cart validation, inventory and security protections before deployment.
