const express = require("express");
const path = require("path");
const shopRoutes = require("./routes/shopRoutes");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware: parse form and JSON request bodies
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// EJS view engine and static files
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.use("/", shopRoutes);

// 404 handler must be after all valid routes
app.use((req, res) => {
  res.status(404).render("404", { title: "Page Not Found" });
});

// Central error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send("Something went wrong. Please try again.");
});

app.listen(PORT, () => {
  console.log(`StyleKart is running at http://localhost:${PORT}`);
});