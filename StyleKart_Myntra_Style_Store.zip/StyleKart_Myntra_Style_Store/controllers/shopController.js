// CONTROLLER: connects routes, models and EJS views
const productModel = require("../models/productModel");
const orderModel = require("../models/orderModel");

exports.home = (req, res) => {
  const products = productModel.getAllProducts().slice(0, 4);
  res.render("home", { title: "StyleKart | Fashion for Everyone", products });
};

exports.shop = (req, res) => {
  const { category = "All", q = "", sort = "" } = req.query;
  const products = productModel.getFilteredProducts({ category, q, sort });
  res.render("shop", { title: "Shop Fashion", products, category, q, sort });
};

exports.productDetails = (req, res) => {
  const product = productModel.getProductById(req.params.id);
  if (!product) return res.status(404).render("404", { title: "Product Not Found" });
  res.render("product", { title: product.name, product });
};

exports.checkout = (req, res) => {
  res.render("checkout", { title: "Checkout" });
};

exports.placeOrder = (req, res) => {
  const { name, email, address, items } = req.body;
  if (!name || !email || !address || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ success: false, message: "Please provide your details and add products to the cart." });
  }
  const order = {
    id: Date.now(),
    customer: { name, email, address },
    items,
    createdAt: new Date().toISOString()
  };
  orderModel.saveOrder(order);
  res.json({ success: true, orderId: order.id });
};

exports.orderSuccess = (req, res) => {
  res.render("success", { title: "Order Placed", orderId: req.params.id });
};