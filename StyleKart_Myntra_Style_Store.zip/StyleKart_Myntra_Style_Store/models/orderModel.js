// MODEL: simple JSON-file order storage using Node.js fs module
const fs = require("fs");
const path = require("path");
const dataDir = path.join(__dirname, "..", "data");
const ordersFile = path.join(dataDir, "orders.json");

function ensureFile() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(ordersFile)) {
    fs.writeFileSync(ordersFile, "[]", "utf8");
  }
}
function getOrders() {
  ensureFile();
  return JSON.parse(fs.readFileSync(ordersFile, "utf8"));
}
function saveOrder(order) {
  const orders = getOrders();
  orders.push(order);
  fs.writeFileSync(ordersFile, JSON.stringify(orders, null, 2), "utf8");
  return order;
}
module.exports = { getOrders, saveOrder };