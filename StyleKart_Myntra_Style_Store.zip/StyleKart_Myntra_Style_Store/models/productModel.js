// MODEL: product data and filtering logic
const products = [
  { id: 1, name: "Classic White Sneakers", brand: "Roadster", category: "Footwear", price: 1299, oldPrice: 2599, rating: 4.4, badge: "BESTSELLER", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700&q=85" },
  { id: 2, name: "Everyday Denim Jacket", brand: "HIGHLANDER", category: "Men", price: 1899, oldPrice: 3299, rating: 4.3, badge: "TRENDING", image: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=700&q=85" },
  { id: 3, name: "Minimal Beige Handbag", brand: "DressBerry", category: "Accessories", price: 999, oldPrice: 1999, rating: 4.2, badge: "HOT DEAL", image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=700&q=85" },
  { id: 4, name: "Floral Summer Dress", brand: "SASSAFRAS", category: "Women", price: 1499, oldPrice: 2799, rating: 4.5, badge: "NEW", image: "https://images.unsplash.com/photo-1612330740210-4b7b6f8f4c1a?w=700&q=85" },
  { id: 5, name: "Everyday Analog Watch", brand: "TIMEX", category: "Accessories", price: 2199, oldPrice: 3999, rating: 4.1, badge: "POPULAR", image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=700&q=85" },
  { id: 6, name: "Casual Cotton T-Shirt", brand: "Roadster", category: "Men", price: 599, oldPrice: 999, rating: 4.0, badge: "UNDER ₹999", image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=700&q=85" },
  { id: 7, name: "Running Sports Shoes", brand: "HRX", category: "Footwear", price: 1799, oldPrice: 3499, rating: 4.3, badge: "TRENDING", image: "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=700&q=85" },
  { id: 8, name: "Everyday Sunglasses", brand: "StyleCast", category: "Accessories", price: 799, oldPrice: 1499, rating: 4.1, badge: "NEW", image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=700&q=85" }
];

// Replace any unavailable image with a known fashion image.
products[6].image = "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=700&q=85";

function getAllProducts() { return products; }
function getProductById(id) { return products.find(p => p.id === Number(id)); }
function getFilteredProducts({ category, q, sort }) {
  let result = [...products];
  if (category && category !== "All") {
    result = result.filter(p => p.category.toLowerCase() === category.toLowerCase());
  }
  if (q) {
    const term = q.toLowerCase();
    result = result.filter(p => `${p.name} ${p.brand} ${p.category}`.toLowerCase().includes(term));
  }
  if (sort === "low") result.sort((a, b) => a.price - b.price);
  if (sort === "high") result.sort((a, b) => b.price - a.price);
  if (sort === "rating") result.sort((a, b) => b.rating - a.rating);
  return result;
}
module.exports = { getAllProducts, getProductById, getFilteredProducts };