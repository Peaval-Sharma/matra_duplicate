// Browser-side JavaScript: localStorage cart, add/remove and checkout
const CART_KEY = "stylekart_cart";
function getCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; }
  catch { return []; }
}
function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
}
function updateCartCount() {
  const count = getCart().reduce((sum, item) => sum + item.qty, 0);
  const badge = document.getElementById("header-cart-count");
  if (badge) badge.textContent = count;
}
async function addProduct(id) {
  try {
    const response = await fetch("/api-not-used");
    void response;
  } catch (_) {}
  // Product details are supplied from a small client-side catalogue.
  const catalogue = window.STYLEKART_PRODUCTS || {};
  const product = catalogue[id];
  if (!product) {
    // The server-rendered page provides product details in the data attributes.
    const button = document.querySelector(`.add-to-cart[data-id="${id}"]`);
    const card = button?.closest("article, section");
    const name = card?.querySelector("h3")?.textContent || document.querySelector("h1")?.textContent || "Fashion item";
    const priceText = card?.querySelector(".font-bold")?.textContent || document.body.innerText.match(/₹\s?[\d,]+/)?.[0] || "₹0";
    const price = Number(priceText.replace(/[^\d]/g, "")) || 0;
    const image = card?.querySelector("img")?.src || document.querySelector("main img")?.src || "";
    const cart = getCart();
    const existing = cart.find(item => item.id === Number(id));
    if (existing) existing.qty += 1;
    else cart.push({ id: Number(id), name, price, image, qty: 1 });
    saveCart(cart);
    button?.classList.add("added");
    if (button) { const old = button.textContent; button.textContent = "Added ✓"; setTimeout(() => button.textContent = old, 1200); }
    return;
  }
}
document.addEventListener("click", event => {
  const button = event.target.closest(".add-to-cart");
  if (button) addProduct(button.dataset.id);
});
function renderCart() {
  const container = document.getElementById("cart-items");
  if (!container) return;
  const cart = getCart();
  const empty = document.getElementById("empty-cart");
  const totalEl = document.getElementById("cart-total");
  if (!cart.length) {
    container.innerHTML = "";
    empty?.classList.remove("hidden");
    if (totalEl) totalEl.textContent = "₹0";
    return;
  }
  empty?.classList.add("hidden");
  container.innerHTML = cart.map(item => `
    <div class="flex gap-4 rounded-xl border border-slate-200 p-3">
      <img src="${escapeHtml(item.image)}" alt="" class="h-24 w-20 rounded-lg object-cover">
      <div class="min-w-0 flex-1"><h3 class="font-bold">${escapeHtml(item.name)}</h3><p class="mt-1 font-semibold">₹${item.price.toLocaleString("en-IN")}</p>
      <div class="mt-2 flex items-center gap-3 text-sm"><button data-action="minus" data-id="${item.id}" class="rounded border px-2">−</button><span>${item.qty}</span><button data-action="plus" data-id="${item.id}" class="rounded border px-2">+</button><button data-action="remove" data-id="${item.id}" class="ml-auto text-xs font-bold text-red-500">REMOVE</button></div></div>
    </div>`).join("");
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  if (totalEl) totalEl.textContent = "₹" + total.toLocaleString("en-IN");
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
}
document.addEventListener("click", event => {
  const btn = event.target.closest("[data-action]");
  if (!btn) return;
  const cart = getCart();
  const item = cart.find(p => p.id === Number(btn.dataset.id));
  if (!item) return;
  if (btn.dataset.action === "plus") item.qty++;
  if (btn.dataset.action === "minus") item.qty = Math.max(1, item.qty - 1);
  if (btn.dataset.action === "remove") cart.splice(cart.indexOf(item), 1);
  saveCart(cart);
  renderCart();
});
const checkoutForm = document.getElementById("checkout-form");
if (checkoutForm) {
  checkoutForm.addEventListener("submit", async event => {
    event.preventDefault();
    const items = getCart();
    if (!items.length) { alert("Your bag is empty."); return; }
    const form = new FormData(checkoutForm);
    const payload = { name: form.get("name"), email: form.get("email"), address: form.get("address"), items };
    try {
      const response = await fetch("/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.message || "Order could not be placed");
      localStorage.removeItem(CART_KEY);
      window.location.href = `/order-success/${result.orderId}`;
    } catch (error) { alert(error.message); }
  });
}
updateCartCount();
renderCart();