const express = require("express");
const router = express.Router();
const shopController = require("../controllers/shopController");

router.get("/", shopController.home);
router.get("/shop", shopController.shop);
router.get("/product/:id", shopController.productDetails); // Dynamic path
router.get("/checkout", shopController.checkout);
router.post("/orders", shopController.placeOrder);
router.get("/order-success/:id", shopController.orderSuccess);

module.exports = router;